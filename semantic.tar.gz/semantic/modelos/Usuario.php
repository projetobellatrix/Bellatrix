<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 27/04/18
 * Time: 13:16
 */

class Usuario
{
    private $id;
    private $nome;
    private $email;
    private $idade;
    private $login_uso;
    private $senha_uso;
    private $codtipuser;


    public function __construct($nome, $email, $idade, $login_uso, $senha_uso, $id=null, $codtipuser)
    {
        $this->id = $id;
        $this->nome = $nome;
        $this->email = $email;
        $this->idade = $idade;
        $this->login_uso = $login_uso;
        $this->senha_uso = $senha_uso;
        $this->codtipuser = $codtipuser;
    }

    /**
     * @return null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param null $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * @param mixed $nome
     */
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getIdade()
    {
        return $this->idade;
    }

    /**
     * @param mixed $idade
     */
    public function setIdade($idade)
    {
        $this->idade = $idade;
    }

    /**
     * @return mixed
     */
    public function getLoginUso()
    {
        return $this->login_uso;
    }

    /**
     * @param mixed $login_uso
     */
    public function setLoginUso($login_uso)
    {
        $this->login_uso = $login_uso;
    }

    /**
     * @return mixed
     */
    public function getSenhaUso()
    {
        return $this->senha_uso;
    }

    /**
     * @param mixed $senha_uso
     */
    public function setSenhaUso($senha_uso)
    {
        $this->senha_uso = $senha_uso;
    }

    /**
     * @return mixed
     */
    public function getCodtipuser()
    {
        return $this->codtipuser;
    }

    /**
     * @param mixed $codtipuser
     */
    public function setCodtipuser($codtipuser)
    {
        $this->codtipuser = $codtipuser;
    }



}