
<h2>Cadastrar-se</h2>

<form method="post" action = "../../controlador/usuario.php?acao=inserir">

    <label for="nome">Nome</label>
    <input type="text" name="nome">

    <label for="email">Email</label>
    <textarea name="email" id="email" cols="30" rows="10"></textarea>

    <label for="idade">Idade</label>
    <input type="number" name="idade">

    <label for="login_uso">Login</label>
    <input type="text" name="login_uso">

    <label for="senha_uso">Senha</label>
    <input type="password" name="senha_uso">

    <input type="submit" name="cadastrar" value="Cadastrar">



</form>