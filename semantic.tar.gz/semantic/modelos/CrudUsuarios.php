<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 27/04/18
 * Time: 13:23
 */

require_once "Usuario.php";
require_once "BDConection.php";

class CrudUsuarios
{
    private $conexao;

    public function __construct()
    {
        $this->conexao = BDConection::getConexao();
    }

    public function getUsuarios(){

        $sql = "select * from usuario order by nome ";
        $resultado = $this->conexao->query($sql);
        $listaUsuarios = [];

        $usuarios = $resultado->fetchAll(PDO::FETCH_ASSOC);
        foreach ($usuarios as $usuario){
            $objeto = new Usuario($usuario['nome'], $usuario['email'], $usuario['idade'], $usuario['login_uso'],$usuario['senha_uso'], $usuario['codtipuser']);
            $listaUsuarios[] = $objeto;
        }
        return $listaUsuarios;
    }

    public function insertUsuario(Usuario $usuario){

        $consulta = "INSERT INTO usuario (nome,email,idade, login_uso, senha_uso, id, codtipuser) VALUES ( '{$usuario->getNome()}', '{$usuario->getEmail()}', '{$usuario->getIdade()}', '{$usuario->getLoginUso()}', '{$usuario->getSenhaUso()}', '{$usuario->getCodtipuser()}')";

        echo $consulta;
        try{
            $this->conexao->exec($consulta);
            //return $res;
        }catch (PDOException $erro){
            return $erro->getMessage();
        }

    }

    public function getUsuario($id){

        $sql      = "SELECT * FROM usuario WHERE id = $id";
        $resultado = $this->conexao->query($sql);
        $usuario  = $resultado->fetch(PDO::FETCH_ASSOC);
        $objeto = new Usuario($usuario['nome'], $usuario['email'], $usuario['idade'], $usuario['login_uso'],$usuario['senha_uso'], $usuario['id'], $usuario['codtipuser']);
        return $objeto;
    }

    public function updateUsuario(Usuario $usuario){

        $consulta = "UPDATE usuario SET nome = '{$usuario->getNome()}', email = '{$usuario->getEmail()}', idade = '{$usuario->getIdade()}', login_uso = '{$usuario->getLoginUso()}', senha_uso = '{$usuario->getSenhaUso()}', codtipuser = '{$usuario->getCodtipuser()}' WHERE id={$usuario->getId()}";
        echo $consulta;
        try{
            $res = $this->conexao->exec($consulta);
            //return $res;
        }catch (PDOException $erro){
            return $erro->getMessage();
        }
    }

    public function deleteUsuario($id){

        $consulta = "DELETE FROM usuario WHERE id = {$id}";
        echo $consulta;
        try{
            $res = $this->conexao->exec($consulta);
            //return $res;
        }catch (PDOException $erro){
            return $erro->getMessage();
        }
    }

    public function login($login, $senha){
        $sql      = "SELECT * FROM usuario WHERE login_uso = '$login' and senha_uso='$senha' ";
        $resultado = $this->conexao->query($sql);
        if($resultado->rowCount() > 0) {
            $usuario = $resultado->fetch(PDO::FETCH_ASSOC);
            $objeto = new Usuario($usuario['nome'], $usuario['email'], $usuario['idade'], $usuario['login_uso'], $usuario['senha_uso'], $usuario['codtipuser']);
            return $objeto;
        }else{
            return false;
        }

    }

}