<?php
    session_start();
    require_once '../modelos/CrudUsuarios.php';


    if (isset($_GET['acao'])){
        $acao = $_GET['acao'];
    }else{
        $acao = 'index';
    }

    switch ($acao){

        case 'index':

            $crud = new CrudUsuarios();
            $usuarios = $crud->getUsuarios();

//            include '../views/usuarios/cabecalho.php';
            include '../views/usuarios/index.php';
//            include '../views/usuarios/rodape.php';
            break;


        case 'inserir';
            if (!isset($_POST['gravar'])){ // se ainda nao tiver preenchido o form
//                include '../views/usuarios/cabecalho.php';
               include '../views/usuarios/index.php';
//                include '../views/usuarios/rodape.php';
            }else{

                // depois de preencher o formulario

                $nome = $_POST['username'];
                $email= $_POST['email'];
                $idade= 8;
                $login= $_POST['username'];
                $senha= $_POST['password'];
                $novoUsuario = new Usuario($nome,$email, $idade, $login, $senha);

                $crud = new CrudUsuarios();
                $crud->insertUsuario($novoUsuario);


                header('Location:../views/usuarios/telaLogin.html');
            }
            break;


        case 'login':
            if(!isset($_POST['entrar'])){ //primeiro clique - exibir formulario
                include '../views/usuarios/telaLogin.html';
            }else{ //depois de clicar em entrar
                $login = $_POST['login'];
                $senha = $_POST['senha'];
                $crud = new CrudUsuarios();
                $usuario = $crud->login($login, $senha);
                var_dump($usuario);
                if ($usuario){ //se deu certo o login
                    $_SESSION['id'] = $usuario->getId();
                    $_SESSION['nome'] = $usuario->getNome();
                    $_SESSION['login'] = $usuario->getLoginUso();
                    header('location: usuario.php');
                }else{

                    header('location: usuario.php?erro=1');
                }


            }

            break;

        case 'logout':
            session_destroy();
            header('location: usuario.php');
            break;
}