<html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../../semantic.css" type="text/css">
  <script type="text/javascript" src="../../semantic.js"></script>
  <title>Bellatrix</title>

  <link rel="stylesheet" type="text/css" href="components/container.css">
  <link rel="stylesheet" type="text/css" href="semantic/components/grid.css">
  <link rel="stylesheet" type="text/css" href="components/header.css">
  <link rel="stylesheet" type="text/css" href="components/image.css">
  <link rel="stylesheet" type="text/css" href="components/menu.css">

  <link rel="stylesheet" type="text/css" href="components/divider.css">
  <link rel="stylesheet" type="text/css" href="components/dropdown.css">
  <link rel="stylesheet" type="text/css" href="components/segment.css">
  <link rel="stylesheet" type="text/css" href="components/button.css">
  <link rel="stylesheet" type="text/css" href="components/list.css">
  <link rel="stylesheet" type="text/css" href="components/icon.css">
  <link rel="stylesheet" type="text/css" href="components/sidebar.css">
  <link rel="stylesheet" type="text/css" href="components/transition.css">

</head>
<style type="text/css">

  .ui.masthead.segment{
    min-height: 700px;
    padding: 1em 0em;
  }
  .ui.masthead.segment {
    background-image: url(https://static.tumblr.com/837b05c2fc442377f813307efe4199fe/zm6ysny/lOYox3x85/tumblr_static_tumblr_static__640.gif);

  }

  .masthead h1.ui.header {
    margin-top: 3em;
    font-size: 4em;
    font-weight: normal;
  }
  .masthead h2 {
    font-size: 1.7em;
    font-weight: normal;
  }

</style>
<body>

  <div class="ui inverted vertical masthead center aligned segment">

    <div class="ui container">
      <div class="ui large secondary inverted pointing menu">

        <a class="active item" href="index.php">Home</a>
        <a class="item" href="#astro">Sobre</a>
        <a class="item" href="#objetivo">Objetivo</a>
          <?php
          if (isset($_SESSION['id'])){
              echo 'Olá '.$_SESSION['nome'];
              echo '<a href="usuario.php?acao=logout">Sair</a>';
          }else{

              echo '<a class="right floated item " style="text-decoration-color: white" href="usuario.php?acao=login">Login</a>';
              if (isset($_GET['erro']) and $_GET['erro']==1){
                  echo ('Usuário ou senha inválidos!');
              }
          }

          ?>

      </div>

    <div class="ui text container">
      <h1 class="ui inverted header">
        Bellatrix
      </h1>
      <h3>Entre nessa viagem...</h3>
      <a class="ui huge inverted orange button" href="../../views/usuarios/telaCadastrar.html">Cadastre-se</a>
    </div>
  </div>
</div>



  <div class="ui vertical stripe segment">
    <div class="ui middle aligned stackable grid container">
      <div class="row">
        <div class="eight wide centered column">
          <h3 class="ui header centered" id="astro">O que é Astronomia?</h3>
          <p>“Astronomia ("lei das estrelas" com origem grego: (άστρο + νόμος) é, basicamente, o estudo dos astros, corpos celestes, planetas, asteroides, enfim, todo corpo que paira no Universo, e sua origem e estrutura. Se resume em uma série de assuntos ligados à ciência, biologia, física e matemática. Envolve diversas observações procurando respostas aos fenômenos físicos que ocorrem dentro e fora da Terra, bem como em sua atmosfera e estuda as origens, evolução e propriedades físicas e químicas de todos os objetos que podem ser observados no céu (e estão além da Terra), bem como todos os processos que os envolvem. O Astrônomo desenvolve e testa teorias, a partir de suas observações.”(MOCELIN, 2010). </p>
          <h3 class="ui header"></h3>
          <p></p>
        </div>
      </div>

    </div>
  </div>
  <div class="ui vertical stripe segment">

  <div class="ui middle aligned stackable grid container">
        <div class="row">
          <div class="eight wide centered column">
            <h3 class="ui header centered" id="objetivo">Objetivo do site.</h3>
            <p>O objetivo do projeto é desenvolver um site de astronomia, o qual possa notificar e divertir os usuários com informações, notícias e imagens ilustrativas. A razão disso é de uma forma dinâmica, atrair o público, para que o mesmo volte a visitar o site.</p>
            <h3 class="ui header"></h3>
            <p></p>
          </div>


        </div>
      </div>
    </div>
  <div class="ui inverted vertical footer  segment">

    <div class="ui inverted section divider"></div>

    <div class="ui center aligned container">

      <div class="ui stackable  inverted divided centered grid">

        <div class="three wide column">

          <h4 class="ui inverted header">Desenvolvedores</h4>

          <div class="ui inverted link list">

            <a href="#" class="item">Bruno Luiz Fhynbeen</a>
            <a href="#" class="item">Gabriela Cordeiro</a>
            <a href="#" class="item">Miriã Gonçalves</a>

          </div>

        </div>


        <div class="three wide column">

          <h4 class="ui inverted header">Instagram</h4>

          <div class="ui inverted link list">

            <a href="#" class="item">bruno_fhynbeen</a>
            <a href="#" class="item">desinteressad</a>
            <a href="#" class="item">mirigoncalvess</a>

          </div>

        </div>

        <div class="three wide column">

          <h4 class="ui inverted header">Facebook</h4>

          <div class="ui inverted link list">

            <a href="#" class="item">Bruno Luiz Fhynbeen</a>
            <a href="#" class="item">Gabriela Cordeiro</a>
            <a href="#" class="item">Miriã Gonçalves</a>

          </div>

        </div>

        <div class="three wide column">

          <h4 class="ui inverted header">Bellatrix</h4>

          <div class="ui inverted link list">

            <a href="#" class="item">Instagram </a>
            <a href="#" class="item">Facebook</a>
            <a href="#" class="item">Gmail </a>

          </div>

        </div>

      </div>

      <div class="ui inverted section divider"></div>


    </div>
  </div>
</body>

</html>